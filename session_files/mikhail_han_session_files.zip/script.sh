#!/usr/bin/env bash

# Benchmark info
echo "TIMING - Starting main script at: $(date)"

# Set working directory to home directory
cd "${HOME}"

#
# Start Jupyter Lab Server
#
source /etc/profile.d/z00_lmod.sh

# Purge the module environment to avoid conflicts
module purge

# Load the require modules
module load apps/miniconda

# List loaded modules
module list

# Benchmark info
echo "TIMING - Starting jupyter at: $(date)"

# Launch the Jupyter Lab Server
set -x
jupyter "lab" --config="${CONFIG_FILE}" 
